/**
	  - @Author(s): Sushma Adepu
	  - @Description: PayPeriod databean 
	*/
	package timesheet;

	public class PayPeriodBean {

		//instance variable
		public String date;

		PayPeriodBean(){
		
		}
		//get the date
		public String getDate() {
			return date;
		}
		//sets the date
		public void setDate(String date) {
			this.date = date;
		}
	}
